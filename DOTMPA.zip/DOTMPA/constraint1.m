%%Cantilever beam design problem
function [y,geq]=constraint5(x)
% Inequality constraints

y(1)=60/(x(1)^3)+27/(x(2)^3)+19/(x(3)^3)+7/(x(4)^3)+1/(x(5)^3)-1;

% If no equality constraint at all, put geq=[] as follows
geq=[];