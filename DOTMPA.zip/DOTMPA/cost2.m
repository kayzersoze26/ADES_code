%%Tension/compression spring design problem
function y=cost3(x)
% Matlab Code by A. Hedar (Nov. 23, 2005).
y = x(1)^2*x(2)*(x(3)+2);