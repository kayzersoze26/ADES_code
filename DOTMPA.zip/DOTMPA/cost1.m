%%Cantilever beam design problem
function y = cost5(x)
% Matlab Code by A. Hedar (Nov. 23, 2005).

y = 0.06224*(x(1)+x(2)+x(3)+x(4)+x(5));



