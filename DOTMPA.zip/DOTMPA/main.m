clear all
close all
clc
warning('off')
k=50;
fhd=@cec19_func;
% Function_name="F10";
Max_iteration=1001;
SearchAgents_no=50;
% [lb,ub,dim,fobj]=Get_Functions_details(Function_name);
% for problem=3:30
for problem=1:10
switch(problem)
    case 1
        lb = -8192;
        ub =8192;
        dim=9;
    case 2
        lb =-16384;
        ub =16384;
        dim=16;
    case 3
        lb = -4;
        ub =4;
        dim = 18;
    otherwise
        lb = -100;
        ub =100; 
        dim=10;
end
lu = [lb * ones(1, dim); ub * ones(1, dim)];
p=10;
% problem=23;
run=30;
FlockNum=5;
k=0;

[Top_predator_fit(problem),Top_predator_pos,Convergence_curve]=EMPA(SearchAgents_no,Max_iteration,lb,ub,dim,problem,fhd,deta);


end
% [Convergance, BestPos,BestVal] = DTCSMO(SearchAgents_no,dim,Max_iteration,FlockNum,lu,problem);
a=1;





